package com.ob.service;
import java.util.List;
import com.ob.dao.IOnlineBankingDao;
import com.ob.dao.OnlineBankingDao;
import com.ob.dtobean.Payee;
import com.ob.exception.OnlineBankingException;

public class OnlineBankingService implements IOnlineBankingService
{
	
	static IOnlineBankingDao daoobj;

	public OnlineBankingService() {
		daoobj=new OnlineBankingDao();
	}


	@Override
	public List<Payee> retrivePayeeDetails(int accountId) throws OnlineBankingException {
	System.out.println("BYE");
		return daoobj.retrivePayeeDetails(accountId);
	}


	@Override
	public int storepayeeDetails(int accountId, int payeeAccountId, String nickname) throws OnlineBankingException {
		
		return daoobj.storepayeeDetails(accountId,payeeAccountId,nickname);
	}


	

	@Override
	public void updatepayeeaccountbal(int payeeaccountid,int transactionAmount) throws OnlineBankingException {
		daoobj.updatepayeeaccountbal(payeeaccountid,transactionAmount);
		
	}


	@Override
	public void updatepayeraccountbal(int accountid,int transactionAmount) throws OnlineBankingException {
		daoobj.updatepayeraccountbal(accountid,transactionAmount);
		
	}


	@Override
	public void fundTransfer(int transaction_id, int accountId, int payeeaccountid, int transactionAmount) throws OnlineBankingException {
		daoobj.fundTransfer(transaction_id,accountId,payeeaccountid,transactionAmount);
		
	}


	@Override
	public String retrivetransactionpwd(int accountId) throws OnlineBankingException {
		
		return daoobj.retrivetransactionpwd(accountId);
	}

	@Override
	public int checkpayeeAccountId(int payeeAccountId) throws OnlineBankingException {
		int result=daoobj.checkpayeeAccountId(payeeAccountId);
		return result;
	}


	@Override  /* case 7*/
	public void updatetransaction(int transaction_id, String transdesc, int transactionAmount, int payeeaccountid,
			String string) throws OnlineBankingException {
		daoobj.updatetransaction(transaction_id,transdesc,transactionAmount,payeeaccountid,string);
		
	}





	
	
	
	
	
	


}
