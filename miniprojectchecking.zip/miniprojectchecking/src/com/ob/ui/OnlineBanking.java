package com.ob.ui;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.Payee;
import com.ob.exception.OnlineBankingException;
import com.ob.service.IOnlineBankingService;
import com.ob.service.OnlineBankingService;

public class OnlineBanking {
	 static Scanner sc=null;
	 static IOnlineBankingService serobj;
	 static CustomerSignUp csu;
	
	
	public OnlineBanking() {
		serobj=new OnlineBankingService();
	}
	
	
	public static void main(String[] args) throws OnlineBankingException, SQLException {
		
		sc=new Scanner(System.in);
		int accountId=123456789;
		
		try {
			
			serobj=new OnlineBankingService();
		 List<Payee> payeelist=serobj.retrivePayeeDetails(accountId);         /*       from payee table       */
	 
    	 for(Payee p:payeelist) {
    		 System.out.println(p);
    	 }
		
    	 System.out.println("ENTER THE PAYEE ACCOUNT ID");
    	 int payeeaccountid=sc.nextInt();
    
    	 for(Payee l:payeelist) {
    		
    		 if(payeeaccountid==l.getPayeeAccId()) {
    			
    			 transaction(accountId,payeeaccountid);
    		 }
    	 }
    	 
    	 
    	 int count=0;
    	 for(Payee k:payeelist) {
    	  if( (payeeaccountid!=k.getAccountId()) && (count==payeelist.size()) ){
    	
    		 System.out.println("REGISTER THE NEW PAYEE ACCOUNT");
    		 System.out.println("ENTER THE PAYEE ACCOUNT ID");
    		 int payeeAccountId=sc.nextInt();
    		 int result=serobj.checkpayeeAccountId( payeeAccountId);    /*       search in account master table      */
    		 
    		    if(result>0) {
    		        System.out.println("ENTER NICKNAME");
    		        String nickname=sc.next();
    		         
    		      /*     status should be pending*/
    		        /*  pin should be send to reg mobile number */  
      		        
    		        int status=serobj.storepayeeDetails(accountId,payeeAccountId,nickname);     /*       to payee details        */
    		 
    		             if(status>0) {
    			              System.out.println("data enter successfully");
    		             }else {
    			              System.out.println("data not entered");
    		             }
    		   }else {
    			   System.out.println("WRONG ACCOUNT ID IS ENTERED");
    		   }
    		 
    	 }/* END OF IF LOOP */
    	 }/*  END OF FOR LOOP*/
		}
    	 catch(NullPointerException e) {
 			System.err.println(e.getMessage());
 		}
	}
	
	
	
	public static void transaction(int accountId,int payeeaccountid) throws OnlineBankingException{
		
		/*int acc_bal=serobj.customerAccountBalance(accountId);/* METHOD NOT IMPLEMENTED HERE (above)*/
		int acc_bal=150000;
		String transpwd=null;
    	System.out.println("ENTER THE TRANSACTION PASSWORD");
    	transpwd=sc.next();                 
    	String usertransactionpwd=serobj.retrivetransactionpwd(accountId);
    	System.out.println(usertransactionpwd);
    	
    	if((transpwd).equals(usertransactionpwd)&&transpwd!=null) {

    		System.out.println("ENTER THE AMOUNT");
    		int transactionAmount=sc.nextInt(); 
    	    int count=0;
    	          do {
    		            if(transactionAmount< acc_bal) {
                              
                        count=3;
    	                int transaction_id=(int)(Math.random()*1000000);
    	                System.out.println("ENTER THE TRANSACTION DESCRIPTION");
    	                String transdesc=sc.next();
    	                System.out.println("SELECT THE TRANSACTION TYPE");
    	                System.out.println(" 1  --->  NEFT");
    	                System.out.println(" 2  --->  RTGS");
    	                System.out.println(" 3  --->  IMPS");
    	                int choice=sc.nextInt();
    	
    	switch (choice) {
		case 1:
			serobj.updatetransaction(transaction_id,transdesc,transactionAmount,payeeaccountid,"NEFT");    /*  to transaction table  AND fund transfer table */  
			serobj.updatepayeeaccountbal(payeeaccountid,transactionAmount);                                  /*   to account master    */
			serobj.updatepayeraccountbal(accountId,transactionAmount);                                /*    to account master     */
			serobj.fundTransfer(transaction_id,accountId,payeeaccountid,transactionAmount);   /*  to fund transfer table */
			System.out.println("NEFT TRANSACTION SUCCESSFUL");
			break;
		case 2:
			serobj.updatetransaction(transaction_id,transdesc,transactionAmount,payeeaccountid,"RTGS");              
			serobj.updatepayeeaccountbal(payeeaccountid,transactionAmount);
			serobj.updatepayeraccountbal(accountId,transactionAmount);
			serobj.fundTransfer(transaction_id,accountId,payeeaccountid,transactionAmount);
			System.out.println("RTGS TRANSACTION SUCCESSFUL");
			break;
		case 3:
			serobj.updatetransaction(transaction_id,transdesc,transactionAmount,payeeaccountid,"IMPS");          
			serobj.updatepayeeaccountbal(payeeaccountid,transactionAmount);
			serobj.updatepayeraccountbal(accountId,transactionAmount);
			serobj.fundTransfer(transaction_id,accountId,payeeaccountid,transactionAmount);
			System.out.println("IMPS TRANSACTION SUCCESSFUL");
			break;
		default:
			System.out.println("INVALID CHOICE . PLEASE ENTER CORRECT OPTION");
			break;
    	               }
        }else{
    	        count++;
    	        System.out.println("YOUR ACCOUNT BALANCE IS INSUFFICIENT TO MAKE TRANSACTION");
                System.out.println("ENTER THE AMOUNT AGAIN");
    	     }	
    	}while(count<3);
    	}else {
    		System.out.println("ENTERED WRONG TRANSACTION PASSWORD");
    	}
 
	}

    	  
    	  
    	  
}/*  transaction close*/
