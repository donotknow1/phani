package com.ob.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.Payee;
import com.ob.dtobean.ServiceTracker;
import com.ob.exception.OnlineBankingException;
import com.ob.util.DBUtil;



public class OnlineBankingDao implements IOnlineBankingDao{
	Connection conn=null;	
	Payee payee=null;
	
	
public OnlineBankingDao() {
		super();
		conn=DBUtil.DbConnection();
		// TODO Auto-generated constructor stub
	}

//**********************************************/
	@Override
	public List<Payee> retrivePayeeDetails(int accountId) throws OnlineBankingException {
		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger log=Logger.getRootLogger();
		
		List<Payee> payeeList=null;
		
		try {
			
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.RETRIVE_PAYEE_ID);
			//Statement st=conn.createStatement();
			//ResultSet rs=st.executeQuery(IQueryMapper.RETRIVE_PAYEE_ID);
			
			pst.setInt(1, accountId);
			ResultSet rs=pst.executeQuery();
			payeeList=new ArrayList<Payee>();
			Payee payee=null;
			
			while(rs.next())
			{
				payee=new Payee(rs.getInt(1),rs.getInt(2), rs.getString(3) );
				payeeList.add(payee);
		    } 
		}
		
		catch (SQLException|NullPointerException e) 
		{
		
			throw new OnlineBankingException("Data can't be retrieved"+e.getMessage());
		}
		return payeeList;
		
	}

//******************************************************/
	@Override
	public int storepayeeDetails(int accountId, int payeeAccountId, String nickname) throws OnlineBankingException {
		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
		
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.PAYEE_INSERT_QRY);
			pst.setInt(1,accountId);	
			pst.setInt(2,payeeAccountId);
			pst.setString(3, nickname);
			status=pst.executeUpdate();
			 
			} catch (SQLException e) {
		//	log.error("payee data is not stored:: "+e.getMessage());
				System.out.println("jhfdsgusa");
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		
		return status;
	}

//**********************************************/
	@Override
	public void updatepayeeaccountbal(int payeeaccountid,int transactionAmount) throws OnlineBankingException{
		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		
		int accountbalance=0;
		try {
		PreparedStatement pst = conn.prepareStatement(IQueryMapper.RETRIVE_ACCOUNT_BAL);
        pst.setInt(1,payeeaccountid);
        ResultSet rs= pst.executeQuery();        
           while(rs.next()) {
        	   accountbalance=rs.getInt(1);
        	   System.out.println(accountbalance);
           }
		}catch(SQLException e) {
			//log.error(" data not retrive "+e.getMessage());
			System.out.println("88888888");
			throw new OnlineBankingException("data not retrive "+e.getMessage());
		}
		int status=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.UPDATE_PAYEE_ACCOUNTBAL);
			pst.setInt(1,accountbalance-payeeaccountid);	
			
			
			status=pst.executeUpdate();
			 
			} catch (SQLException e) {
		//	log.error("payee data is not stored:: "+e.getMessage());
				System.out.println("ff3333666");
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		if(status>0) {
			System.out.println("balance updated");
		}
		
		
	}

//********************************************/
	@Override
	public void updatepayeraccountbal(int accountId,int transactionAmount) throws OnlineBankingException {
		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		
		int accountbalance=0;
		try {
		PreparedStatement pst = conn.prepareStatement(IQueryMapper.RETRIVE_ACCOUNT_BAL);
        pst.setInt(1,accountId);
        ResultSet rs= pst.executeQuery();        
           while(rs.next()) {
        	   accountbalance=rs.getInt(1);       
           }
		}catch(SQLException e) {
			//log.error(" data not retrive "+e.getMessage());
			System.out.println("f22222222");
			throw new OnlineBankingException("data not retrive "+e.getMessage());
		}
		int status=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.UPDATE_PAYEE_ACCOUNTBAL);
			pst.setInt(1,accountbalance-accountId);	
			
			
			status=pst.executeUpdate();
			 
			} catch (SQLException e) {
		//	log.error("payee data is not stored:: "+e.getMessage());
				System.out.println("bfdigbd");
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		if(status>0) {
			System.out.println("balance updated");
		}
		
		
	}

//*************************************************/
	@Override
	public void fundTransfer(int transaction_id, int accountId, int payeeaccountid, int transactionAmount) throws OnlineBankingException {
		
		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
		
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.INSERT_FUND_TRANSFER);
			pst.setInt(1,transaction_id);	
			pst.setInt(2,accountId);
			pst.setInt(3,payeeaccountid);
			pst.setInt(4,transactionAmount);
			
			status=pst.executeUpdate();
			 
			} catch (SQLException e) {
			//log.error("payee data is not stored:: "+e.getMessage());
			System.out.println("DATA NOT ENTERED ");
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		if(status>0) {
			System.out.println("DATA ENTERED SUCCESSFULLY");
		}else {
			System.out.println("DATA NOT ENTERED ");
		}
	
		
	}

//********************************************/
	@Override
	public String retrivetransactionpwd(int accountId) throws OnlineBankingException {
		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		List<Payee> payeeList=null;
		String transactionpwd=null;
		
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.RETRIVE_TRANSACTION_PWD);
            pst.setInt(1,accountId);
            ResultSet rs= pst.executeQuery();        
               while(rs.next()) {
            	    transactionpwd=rs.getString(1);       
               }
		    }catch (SQLException e) 
		    {
		
			     throw new OnlineBankingException("Data can't be retrieved"+e.getMessage());
		    }
	
		return  transactionpwd;
		
		
		
	}

//****************************************/
	@Override
	public int checkpayeeAccountId(int payeeAccountId) throws OnlineBankingException {
		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int count=0;
		try {
			
			 PreparedStatement ps = conn.prepareStatement(IQueryMapper.RETRIVE_PAYEE_ACCOUNTID);
			ps.setInt(1,payeeAccountId);
		    ResultSet resultSet = ps.executeQuery();
			if(resultSet.next()) {
			    count = resultSet.getInt(1);
			}
		}
		catch (SQLException e) 
		{
			throw new OnlineBankingException("Data can't be retrieved"+e.getMessage());
		}
		return count;
	}

//***********************************************/
	@Override
	public void updatetransaction(int transaction_id, String transdesc, int transactionAmount, int payeeaccountid,
			String string) throws OnlineBankingException {
		//PropertyConfigurator.configure("resources/log4j.properties");
		//Logger log=Logger.getRootLogger();
		conn=DBUtil.DbConnection();
		int status=0;
		
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.INSERT_TRANSACTION);
			pst.setInt(1,transaction_id);	
			pst.setString(2,transdesc);
			pst.setString(3, string);
			pst.setInt(4,transactionAmount);
			pst.setInt(5,payeeaccountid);
			status=pst.executeUpdate();
			 
			} catch (SQLException e) {
			//log.error("payee data is not stored:: "+e.getMessage());
				System.out.println("DATA NOT ENTERED ");
			throw new OnlineBankingException("data not stored "+e.getMessage());
		}
		if(status>0) {
			System.out.println("DATA ENTERED SUCCESSFULLY  update trans");
		}else {
			System.out.println("DATA NOT ENTERED ");
		}
	
		
		
		
	}




}
